// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Ingest to bronze layer"); }
int main(){
  announce();
  return lionss_run_workload("IngestBronze");
}

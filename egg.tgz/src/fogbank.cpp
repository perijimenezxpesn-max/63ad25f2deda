// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Advect fogbank\n", stdout);
  return lionss_run_workload("fogbank");
}

// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Hydrate shell"); }
int main(){
  announce();
  return lionss_run_workload("ssrHydrate");
}

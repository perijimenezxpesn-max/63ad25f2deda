// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Hash-aggregate groups\n", stdout);
  return lionss_run_workload("hashAgg");
}

// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Shrink failing case"); }
int main(){
  announce();
  return lionss_run_workload("prop_shrink");
}

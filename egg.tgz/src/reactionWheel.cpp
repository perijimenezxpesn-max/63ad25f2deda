// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Desaturate reaction wheel\n", stdout);
  return lionss_run_workload("reactionWheel");
}
